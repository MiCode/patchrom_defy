#!/system/xbin/sh
######## BootMenu Script
######## Execute [2nd-init] Menu

echo "export PATH=/sbin:/system/xbin:/system/bin"
export PATH=/sbin:/system/xbin:/system/bin

######## Main Script

echo "mount -o remount,rw /"
mount -o remount,rw /
echo "rm -f /*.rc"
rm -f /*.rc
echo "cp -f /system/bootmenu/2nd-init/* /"
cp -f /system/bootmenu/2nd-init/* /
echo "cp -f /system/bootmenu/binary/adbd /sbin/adbd"
cp -f /system/bootmenu/binary/adbd /sbin/adbd

echo "ADBD_RUNNING"
ADBD_RUNNING=`ps | grep adbd | grep -v grep`
if [ -z "$ADB_RUNNING" ]; then
    rm -f /sbin/adbd.root
fi

## unmount devices
echo "sync"
sync
echo "umount /acct"
umount /acct
echo "umount /dev/cpuctl"
umount /dev/cpuctl
echo "umount /dev/pts"
umount /dev/pts
echo "umount /mnt/asec"
umount /mnt/asec
echo "umount /mnt/obb"
umount /mnt/obb
echo "umount /cache"
umount /cache
echo "umount /data"
umount /data
echo "mount -o remount,rw,relatime,mode=775,size=128k /dev"
mount -o remount,rw,relatime,mode=775,size=128k /dev

######## Cleanup
echo "rm -f /sbin/lsof"
rm -f /sbin/lsof

echo "busybox cleanup.."
## busybox cleanup..
for cmd in $(/sbin/busybox --list); do
  [ -L "/sbin/$cmd" ] && rm "/sbin/$cmd"
done

echo "rm /sbin/busybox"
rm /sbin/busybox

## used for adbd shell (can be bash also)
echo "/system/xbin/ln -s /system/xbin/busybox /sbin/sh"
/system/xbin/ln -s /system/xbin/busybox /sbin/sh

## reduce lcd backlight to save battery
echo "echo 18 > /sys/class/leds/lcd-backlight/brightness"
echo 18 > /sys/class/leds/lcd-backlight/brightness

######## Let's go
echo "/system/bootmenu/binary/2nd-init"
/system/bootmenu/binary/2nd-init

