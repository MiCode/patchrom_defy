#!/system/bin/sh
insmod /system/lib/modules/symsearch.ko
insmod /system/lib/modules/backlight.ko animate=1 brightness=1 log_enable=0 hook_enable=0 defy_plus=1