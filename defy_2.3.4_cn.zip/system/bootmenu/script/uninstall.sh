#!/sbin/sh

######## BootMenu Script

export PATH=/sbin:/system/xbin:/system/bin

######## Main Script

busybox mount -o remount,rw /system

rm /system/bin/logwrapper
rm /system/bin/bootmenu
mv /system/bin/logwrapper.bin /system/bin/logwrapper

rm -r /system/bootmenu

sync

reboot

