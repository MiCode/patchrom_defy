
insert into providers ("_id", "dirty", "sync_id", "provider", "pretty_name", "path", "ui_order", "login_label", "fallback_url", "multiple_accounts", "provider_url", "pwd_storage_policy") values ('41', '0', 'iICP8VY4T4O6wrnA3sskHw==', 'renren', '人人', 'https://ws-cloud503-blur.svcmot.com/blur-services-1.0/images/accountsetup/hdpi/renren', '12', '账号:|已注册的账号', 'http://m.renren.com', '0', 'http://m.renren.com', '2');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('42', '0', 'Au71O1XjTNO4cGtrwCQ4Og==', '41', '10', '', '0', '0', 'Xiaonei Mini-Feed.png', '人人新鲜事', '0', '
{
"friendfeedReactionDefs":[
{"reactionDefs":[{"userParamDefs":[{"maxLength":200,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败 人人"}}],"group":"PHOTO","supportsComments":1,"type":"PHOTO_ADDED","label":"新建照片"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":500,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败 人人"}}],"type":"PHOTO_COMMENT","label":"新建评论"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":500,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败 人人"}}],"type":"PHOTO_TAG","label":"描述照片"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":500,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败 人人"}}],"type":"PHOTO_OTHER","label":"照片更新"},
{"reactionDefs":[{"order":2,"name":"accept","label":"接受","messages":{"ok":"接受好友请求","fail":"发送好友请求回应失败 人人"},"flags":1},{"order":3,"name":"reject","label":"拒绝","messages":{"ok":"忽略好友请求","fail":"发送好友请求回应失败 人人"},"flags":1}],"group":"FRIEND_REQUEST","type":"FRIEND_REQUEST","label":"好友请求"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":500,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentBlog","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"BLOG","supportsComments":1,"type":"BLOG_CREATED","label":"发布博客"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":500,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentBlog","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"type":"BLOG_COMMENT","label":"评论"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":500,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentBlog","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"type":"BLOG_OTHER","label":"博客更新"},
{"reactionDefs":[{"order":2,"name":"poke","label":"回应打招呼","messages":{"ok":"打招呼已发送","fail":"无法发送打招呼 人人"},"flags":1}],"type":"POKE","label":"打招呼"}
]}
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('43', '0', 'tvYCZdq4SD6BOeu9X9X38A==', '41', '11', '', '80', '1', 'Xiaonei Friends.png', '人人好友', '0', '
{
  "friendActionDefs":
	[
		{"userParamDefs":
			[ 
				{"maxLength":2000,"name":"comment","label":"留言","type":"string"}
			],
			"order":0,"name":"comment","label":"留言","messages":{"ok":"留言已发送","fail":"发送留言失败 人人"}
		},
		{"order":2,"name":"poke","label":"打招呼","messages":{"ok":"打招呼已发送","fail":"无法发送打招呼 人人"}}
	],
  "sync_sources_settings" : [
        {
           "source_name":"renren",
           "pretty_name":"人人",
           "allow_out_of_context":1,
           "active_sync_source":0,
           "is_picture_source":1
  		}
    ]
 }
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('44', '0', 'CMcXQzzGRNSaCd1ZlN7xoA==', '41', '6', '', '0', '0', 'Xiaonei Photos.png', '人人照片', '0', '
{
"blurGallerySupported": "1",
"profilePicSupported": "1",
"photoShareSupported": "1",
"titleSupported": "0",

"descSupported": "1",
"descRequired": "0",

"maxTimeoutBeforeError": "600",
"supportedMIMETypes": ["GIF","JPEG","PNG", "BMP", "JPG"],
"maxUploadSize" : {"width":1220,"height":1220},

"maxBatchSize" : "20",

"album": {
	"actions": [
		
		{"name":"头像相册","allow":[],"deny":["UPLOAD","DELETE","UPDATE","CREATE+LOCATION","UPDATE+LOCATION","DELETE+LOCATION","DELETE_CONTENT"]},
		{"name":"手机相册","allow":[],"deny":["DELETE", "UPDATE", "UPDATE+TITLE","UPDATE+LOCATION", "UPDATE+DESCRIPTION"]},
                {"name":"","allow":[],"deny":["DELETE", "UPDATE+TITLE","UPDATE+LOCATION", "UPDATE+DESCRIPTION"]}
	],

	"options": [
		{"title":{"maxLength":30}},
		{"description":{"maxLength":200}},
		{"location":{"maxLength":60}}
	],

	"content": [
	{
		"image":{		
		"actions":{"allow":[],"deny":["UPDATE+TITLE","UPDATE+CAPTION","UPDATE+LOCATION"]},
			"options": [
				{"title"  :{"maxLength": 60}},
                {"caption":{"maxLength":200 } },
				{"location":{"maxLength":60 } },
				{"comment":{"maxLength":500}}
				
			],
			"size": [
				{"type":"thumb" ,"maxWidth":100,"maxHeight":300},
				{"type":"medium","maxWidth":200,"maxHeight":600},
				{"type":"large" ,"maxWidth":600,"maxHeight":1800}
			]
		}
	}
	]
}

}
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('45', '0', 'GkiQyaDKSkukPiQ/UDQX4g==', '41', '9', '', '80', '1', 'Xiaonei Messaging.png', '人人站内信', '0', '
	{
                "clientViewOption":"UNUSED",
                "emptySubjectAllowed":"TRUE",
		"moveToFolders":[],
		"threadActions":["DELETE_THREAD","REPLY_THREAD","MARK_READ_THREAD","MARK_UNREAD_THREAD"],
		"folderTypes":["INBOX","SENT"],
		"folderNames":["收件箱","已发送信件"],
		"bodyFormats":["TEXT"],
		"attributes":[
			{"name":"REPLY_THREAD_TYPES","value":["USER"],"type":"list"},
			{"name":"ADDRESSEE_LIMIT","value":"1","type":"int"},
			{"name":"ADDRESSEE_TYPES","value":["MEMBER_ID","SMTP"],"type":"list"},
			{"name":"SUBJECT"},{"name":"SUBJECT_LIMIT","value":"200","type":"int"},
			{"name":"BODY"},{"name":"BODY_LIMIT","value":"5000","type":"int"},
			{"name":"ATTACHMENT","value":["URL"],"type":"list"},
			{"name":"MESSAGE_READ_STATE"},
			{"name":"THREAD_ID"},
			{"name":"MESSAGE_ID"},
			{"name":"REPLY_TO_TYPE","value":["THREAD_ID"],"type":"list"}
		],
		"messageActions":["SEND_MSG"]
	}
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('46', '0', 'CAJnAUU6SuSX2e29jTxlvw==', '41', '8', '', '0', '0', 'Xiaonei Status.png', '人人状态心情', '0', '
{"pushProviderID":5,"maxLength":140,"clearStatusSupported":0, "supportsComments":1,
 "statusReactionDefs":[{"userParamDefs":[{"maxLength":140,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentStatus","label":"添加评论","type":"comment","messages":{"ok":"评论已发送","fail":"发送评论失败 人人"}}			                       
]}    
', '', '');


insert into providers ("_id", "dirty", "sync_id", "provider", "pretty_name", "path", "ui_order", "login_label", "fallback_url", "multiple_accounts", "provider_url", "pwd_storage_policy") values ('42', '0', '9xr44ycMTtGF0gwlQI2IOQ==', 'fiveone', '51', 'https://ws-cloud503-blur.svcmot.com/blur-services-1.0/images/accountsetup/hdpi/fiveone', '14', '账号:|已注册的账号', 'http://wap.51.com', '0', 'http://www.51.com', '2');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('52', '0', 'FisDWzteRnqucDeJjY+3wA==', '42', '10', '', '0', '0', 'FiveOne Mini-Feed.png', '51好友动态', '0', '
{
"friendfeedReactionDefs":[
{"reactionDefs":[{"userParamDefs":[{"maxLength":1000,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"PHOTO","supportsComments":1,"type":"PHOTO_ADDED","label":"新建照片"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":1000,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"PHOTO","type":"PHOTO_COMMENT","label":"新建评论"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":1000,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"PHOTO","type":"PHOTO_TAG","label":"描述照片"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":1000,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"PHOTO","type":"PHOTO_OTHER","label":"照片更新"},
{"reactionDefs":[],"group":"","type":"RELATIONSHIP_UPDATE", "label":"好友更新"},
{"reactionDefs":[{"order":2,"name":"accept","label":"接受","messages":{"ok":"接受好友请求","fail":"发送好友请求回应失败"},"flags":1},{"order":3,"name":"reject","label":"拒绝","messages":{"ok":"忽略好友请求","fail":"发送好友请求回应失败"},"flags":1}],"group":"FRIEND_REQUEST","type":"FRIEND_REQUEST","label":"好友请求"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":500,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentBlog","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"BLOG","supportsComments":1,"type":"BLOG_CREATED","label":"发布博客"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":500,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentBlog","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"type":"BLOG_COMMENT","label":"评论"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":500,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentBlog","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"type":"BLOG_OTHER","label":"博客更新"},
{"reactionDefs":[],"group":"","type":"FRIENDSHIP_UPDATE", "label":"好友更新"},
{"reactionDefs":[],"group":"","type":"FRIEND_OTHER", "label":"更新"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":100,"name":"comment","label":"回复","type":"string"}],"order":2,"name":"replyWallPosts","label":"回复","messages":{"ok":"留言回复已发送","fail":"发送留言回复失败"}}],"type":"NEW_WALL_POST","label":"新建留言"},
{"reactionDefs":[],"group":"","type":"PROFILE_UPDATE", "label":"好友更新"},
{"reactionDefs":[],"group":"PHOTO","type":"PROFILE_PIC_UPDATE", "label":"好友更换了头像"},
{"reactionDefs":[],"group":"","type":"OTHER", "label":"更新"}
]}
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('53', '0', 'jf6afkYxT+6ZBF2oMn8XJA==', '42', '11', '', '80', '1', 'Fiveone Friends.png', '51好友', '0', '
{
  "friendActionDefs":
	[
		{"userParamDefs":
			[ 
				{"maxLength":1000,"name":"comment","label":"留言","type":"string"}
			],
			"order":0,"name":"comment","label":"留言","messages":{"ok":"留言已发送","fail":"发送留言失败"}
		}
	],
  "sync_sources_settings" : [
        {
           "source_name":"fiveone",
           "pretty_name":"51",
           "allow_out_of_context":1,
           "active_sync_source":0,
           "is_picture_source":1
        }
    ]
 }
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('54', '0', '3KhCUDu8RUSQqTQOmVQpNw==', '42', '6', '', '0', '0', 'FiveOne Photos.png', '51照片', '0', '
{ "photoShareSupported":"1", "titleSupported":"0", "descSupported":"1", "descRequired":"0", "maxDescLength":"30", "maxTimeoutBeforeError":"600", "profilePicSupported":"0", "supportedMIMETypes":[
    "GIF", "JPEG", "PNG", "BMP"]
}    
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('55', '0', 'SY3sMlakS3mdOkqzjKSx4Q==', '42', '8', '', '0', '0', 'FiveOne Status.png', '51状态', '0', '
{"pushProviderID":9,"maxLength":255,"clearStatusSupported":0, "supportsComments":1,
 "statusReactionDefs":[{"userParamDefs":[{"maxLength":1000,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentStatus","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}			                       
]}    
', '', '');


insert into providers ("_id", "dirty", "sync_id", "provider", "pretty_name", "path", "ui_order", "login_label", "fallback_url", "multiple_accounts", "provider_url", "pwd_storage_policy") values ('201', '0', 'bwtUKk9dTXGP2CH/+aoc/g==', 'kaixin001', '开心', 'https://ws-cloud503-blur.svcmot.com/blur-services-1.0/images/accountsetup/hdpi/kaixin001', '11', '账号:|已注册的账号', 'http://wap.kaixin001.com', '0', 'http://wap.kaixin001.com', '2');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('202', '0', 'e2gfnmWjSAiItoD2CCX/1w==', '201', '8', '', '0', '0', 'Kaixin001 Status.png', '开心状态心情', '0', '
{"pushProviderID":8,"maxLength":255,"clearStatusSupported":0,"supportsComments":1,
 "statusReactionDefs":[{"userParamDefs":[{"maxLength":1000,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentStatus","label":"添加评论","type":"comment","messages":{"ok":"评论已发送","fail":"发送评论失败"}}			                       
]}    
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('203', '0', 'Yi8dniQwSVi4nDh7WfDutQ==', '201', '11', '', '80', '1', 'Kaixin001 Friends.png', '开心好友', '0', '
{
  "friendActionDefs":
	[
		{"userParamDefs":
			[
				{"maxLength":1000,"name":"comment","label":"留言","type":"string"}
			],
			"order":0,"name":"comment","label":"留言","messages":{"ok":"留言已发送","fail":"发送留言失败"}
		},
		{"order":2,"name":"poke","label":"动他一下","messages":{"ok":"动他一下发送成功","fail":"动他一下发送失败"}}
	],
  "sync_sources_settings" : [
        {
           "source_name":"kaixin001",
           "pretty_name":"开心",
           "allow_out_of_context":1,
           "active_sync_source":0,
           "is_picture_source":1
        }
    ]
 }
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('204', '0', 'YIp8zuAzQr+ioN9mKg5o4Q==', '201', '10', '', '0', '0', 'Kaixin001 Mini-Feed.png', '开心好友动态', '0', '
{
"friendfeedReactionDefs":[
{"reactionDefs":[{"userParamDefs":[{"maxLength":200,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentNote","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"NOTE","supportsComments":1,"type":"NOTE_CREATED","label":"新建记录"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":200,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentNote","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"NOTE","supportsComments":1,"type":"NOTE_COMMENT","label":"新建评论"},
{"reactionDefs":[],"group":"NOTE","type":"NOTE_OTHER", "label":"更新"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":128,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"PHOTO","supportsComments":1,"type":"PHOTO_ADDED","label":"新建照片"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":128,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"PHOTO","supportsComments":1,"type":"PHOTO_COMMENT","label":"新建评论"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":128,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"PHOTO","supportsComments":1,"type":"PHOTO_TAG","label":"描述照片"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":128,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentPhoto","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"PHOTO","supportsComments":1,"type":"PHOTO_OTHER","label":"照片更新"},
{"reactionDefs":[{"order":2,"name":"accept","label":"同意该请求","messages":{"ok":"接受好友请求","fail":"发送好友请求回应失败"},"flags":1},{"order":3,"name":"reject","label":"忽略该请求","messages":{"ok":"忽略好友请求","fail":"发送好友请求回应失败"},"flags":1}],"group":"FRIEND_REQUEST","type":"FRIEND_REQUEST","label":"好友请求"},
{"reactionDefs":[],"group":"","type":"FRIEND_OTHER", "label":"更新"},
{"reactionDefs":[],"group":"PHOTO","type":"PROFILE_PIC_UPDATE", "label":"好友更换了头像"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":1000,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentBlog","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"BLOG","supportsComments":1,"type":"BLOG_CREATED","label":"新日记"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":1000,"name":"comment","label":"添加评论","type":"string"}],"order":2,"name":"commentBlog","label":"添加评论","messages":{"ok":"评论已发送","fail":"发送评论失败"}}],"group":"BLOG","supportsComments":1,"type":"BLOG_COMMENT","label":"评论"},
{"reactionDefs":[],"group":"BLOG","type":"BLOG_OTHER", "label":"日记更新"},
{"reactionDefs":[{"order":2,"name":"poke","label":"我要回应","messages":{"ok":"动他一下发送成功","fail":"动他一下发送失败"},"flags":1}],"type":"POKE","label":"动他一下"},
{"reactionDefs":[],"reactionDefs4":[{"order":0,"name":"previewPurchase","label":"Preview/Purchase","flags":4,"requiredFeatures":2}],"group":"MUSIC","type":"LOVED_TRACKS","label":"喜欢的乐曲"},
{"reactionDefs":[],"reactionDefs4":[{"order":0,"name":"previewPurchase","label":"Preview/Purchase","flags":4,"requiredFeatures":2}],"group":"MUSIC","type":"RECENT_TRACKS","label":"Listened a track"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":1000,"name":"comment","label":"回复","type":"string"}],"order":2,"name":"replyWallPosts","label":"回复","messages":{"ok":"留言回复已发送","fail":"发送留言回复失败"}}],"group":"","type":"NEW_WALL_POST","label":"新建留言"},
{"reactionDefs":[{"userParamDefs":[{"maxLength":1000,"name":"comment","label":"回复","type":"string"}],"order":2,"name":"replyWallPosts","label":"回复","messages":{"ok":"留言回复已发送","fail":"发送留言回复失败"}}],"group":"","type":"WALL_REPLY","label":"回复留言"},
{"reactionDefs":[],"group":"","type":"OTHER", "label":"更新"}
]}
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('205', '0', '4qb/nJ02RA220ayAcnk0bQ==', '201', '9', '', '80', '1', 'Kaixin001 Messaging.png', '开心短消息', '0', '
	{
                "clientViewOption":"UNUSED",
                "emptySubjectAllowed":"TRUE",
		"moveToFolders":[],
		"threadActions":["DELETE_THREAD","REPLY_THREAD"],
		"folderTypes":["INBOX","SENT"],
		"folderNames":["收件箱","已发送信件"],
		"bodyFormats":["TEXT","HTML"],
		"attributes":[
			{"name":"REPLY_THREAD_TYPES","value":["USER"],"type":"list"},
			{"name":"ADDRESSEE_LIMIT","value":"20","type":"int"},
			{"name":"ADDRESSEE_TYPES","value":["MEMBER_ID"],"type":"list"},
			{"name":"BODY"},{"name":"BODY_LIMIT","value":"2000","type":"int"},
			{"name":"MESSAGE_READ_STATE"},
			{"name":"THREAD_ID"},
			{"name":"MESSAGE_ID"},
			{"name":"REPLY_TO_TYPE","value":["THREAD_ID"],"type":"list"}
		],
		"messageActions":["SEND_MSG","REPLY_MSG"]
	}
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('206', '0', 'ilOVnouUQf2aO0xKp9hWfQ==', '201', '6', '', '0', '0', 'Kaixin001 Photos.png', '开心照片', '0', '
{
"blurGallerySupported": "1", 
"photoShareSupported":"1", 
"titleSupported":"1", 
"descSupported":"1", 
"descRequired":"0", 
"maxDescLength":"100", 
"maxTimeoutBeforeError":"600", 
"profilePicSupported":"0", 
"maxUploadSize" : {"width":780,"height":600,"size":"10485760"},
"supportedMIMETypes":["GIF", "JPEG", "PNG", "BMP" ],

"maxFileSize": "10485760",
"maxBatchSize" : "20",

"album": {
	"actions": [
        {"name":"头像照","allow":[],"deny":["UPLOAD","DELETE","UPDATE","CREATE+LOCATION","UPDATE+LOCATION","DELETE+LOCATION","DELETE_CONTENT"]},
		{"allow": [], "deny":["DELETE"]}
	],

	"options": [
		{"title":{"maxLength":128}},
		{"description":{"maxLength":1000}},
		{"location":{"maxLength":100}}
	],

	"content": [
	{
		"image":{
		    "actions":{"allow":[],"deny":["DELETE+LIKE", "UPDATE+TITLE+头像照", "CREATE+PERSON+头像照","DELETE+PERSON+头像照"]},
			"options": [
				{"title"  :{"maxLength": 128}},
				{"person" :{"maxLength":128, "values":["x","y","x2","y2"] } },
				{"comment":{"maxLength":6000}},
				{"like"   :{"title":"赞","label":"赞","values":[1..1000]}}
			],
			"size": [
				{"type":"thumb" ,"maxWidth":225,"maxHeight":75},
				{"type":"medium","maxWidth":225,"maxHeight":75},
				{"type":"large" ,"maxWidth":604,"maxHeight":604}
			]
		}
	}
	]
}
}    
', '', '');


insert into providers ("_id", "dirty", "sync_id", "provider", "pretty_name", "path", "ui_order", "login_label", "fallback_url", "multiple_accounts", "provider_url", "pwd_storage_policy") values ('321', '0', 'WqQtOrjXTgStGwx+FRMN1A==', 'sinamicroblog', '新浪微博', 'https://ws-cloud503-blur.svcmot.com/blur-services-1.0/images/accountsetup/hdpi/sinamicroblog', '10', '用户名:|用户名', 'http://t.sina.com.cn', '0', 'http://t.sina.com.cn', '3');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('322', '0', 'IWGUH1V7RpG2PXRn8Ou++Q==', '321', '9', '', '80', '1', 'SinaMicroblog Messaging.png', 'sinamicroblog_messaging', '0', '
{
        "clientViewOption":"UNUSED",
        "emptySubjectAllowed":"TRUE",
	"moveToFolders":[],
	"threadActions":[],
	"folderTypes":["INBOX","SENT"],
	"folderNames":["收件箱","发件箱"],
	"bodyFormats":["TEXT","HTML"],
	"attributes":[
		{"name":"ADDRESSEE_LIMIT","value":"1","type":"int"},
		{"name":"ADDRESSEE_TYPES","value":["MEMBER_ID"],"type":"list"},
		{"name":"BODY"},{"name":"BODY_LIMIT","value":"140","type":"int"},
		{"name":"MESSAGE_ID"}],
	"messageActions":["SEND_MSG","DELETE_MSG"]
} 
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('323', '0', 'fEIdvzu8Qx6t0F965mYfOg==', '321', '6', '', '0', '0', 'SinaMicroblog Photos.png', 'sinamicroblog_photos', '0', '
{
  "photoShareSupported": "1",
  "titleSupported": "1",
  "titleRequired": "1",
  "descSupported": "1",
  "descRequired": "1",
  "maxTimeoutBeforeError": "600",
  "profilePicSupported": "1",
  "supportedMIMETypes": [ "JPEG", "GIF", "PNG" ],
  
  "maxFileSize": "5242880",
  
  "album": {
         "content": [{
                    "image": {
                           "options": [
                                    { "title": { "maxLength": 140 } },
                                    { "caption": { "maxLength": 140 } }
                            ]
                     }
        }]
  }
}
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('324', '0', 'e7DW4clBSz2VIR72op9dAg==', '321', '11', '', '80', '1', 'SinaMicroblog Friends.png', 'sinamicroblog_friends', '0', '
{
"friendActionDefs":[{"userParamDefs":[{"maxLength":118,"name":"comment","label":"@回复","type":"string","prefix":"@{friendName} ","totalMaxLength":140}],"order":0,"name":"comment","label":"@回复","messages":{"ok":"评论已发送","fail":"发送评论失败 Twitter"}}
],
   "sync_sources_settings" : [
        {
           "source_name":"sinamicroblog",
           "pretty_name":"新浪微博",
           "allow_out_of_context":1,
           "active_sync_source":0,
           "is_picture_source":1
        }
    ]

}
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('325', '0', 'h+htDxNKR/mzSTAsmQ31+g==', '321', '10', '', '0', '0', 'SinaMicroblog Mini-Feed.png', 'sinamicroblog_mini-feed', '0', '
{
"friendfeedReactionDefs":[
{"reactionDefs":[],"group":"EVENT","type":"EVENT_CREATED", "label":"New event"},
{"reactionDefs":[],"group":"EVENT","type":"EVENT_INVITATION", "label":"拒绝约会邀请"},
{"reactionDefs":[],"group":"EVENT","type":"EVENT_UPDATE", "label":"Event update"},
{"reactionDefs":[],"group":"EVENT","type":"EVENT_OTHER", "label":"Event update"},
{"reactionDefs":[],"group":"GROUP","type":"GROUP_CREATED", "label":"New group"},
{"reactionDefs":[],"group":"GROUP","type":"GROUP_INVITATION", "label":"组要求"},
{"reactionDefs":[],"group":"GROUP","type":"GROUP_JOINED", "label":"加入组"},
{"reactionDefs":[],"group":"GROUP","type":"GROUP_OTHER", "label":"组更新"},
{"reactionDefs":[],"group":"PHOTO","type":"PHOTO_ADDED", "label":"新建照片"},
{"reactionDefs":[],"group":"PHOTO","type":"PHOTO_COMMENT", "label":"新建评论"},
{"reactionDefs":[],"group":"PHOTO","type":"PHOTO_TAG", "label":"描述照片"},
{"reactionDefs":[],"group":"PHOTO","type":"PHOTO_OTHER", "label":"照片更新"},
{"reactionDefs":[],"group":"ALBUM","type":"ALBUM_CREATED", "label":"新建相册"},
{"reactionDefs":[],"group":"NOTE","type":"NOTE_CREATED", "label":"新建记录"},
{"reactionDefs":[],"group":"NOTE","type":"NOTE_OTHER", "label":"更新"},
{"reactionDefs":[],"group":"","type":"RELATIONSHIP_UPDATE", "label":"好友更新"},
{"reactionDefs":[],"group":"FRIEND_REQUEST","type":"FRIEND_REQUEST", "label":"好友请求"},
{"reactionDefs":[],"group":"","type":"FRIENDSHIP_UPDATE", "label":"好友更新"},
{"reactionDefs":[],"group":"","type":"FRIEND_OTHER", "label":"更新"},
{"reactionDefs":[],"group":"","type":"NEW_WALL_POST", "label":"新建留言"},
{"reactionDefs":[],"group":"","type":"PROFILE_UPDATE", "label":"好友更新"},
{"reactionDefs":[],"group":"MUSIC","type":"PROFILE_MUSIC_UPDATE", "label":"好友更新"},
{"reactionDefs":[],"group":"PHOTO","type":"PROFILE_PIC_UPDATE", "label":"好友更换了头像"},
{"reactionDefs":[],"group":"VIDEO","type":"PROFILE_VIDEO_UPDATE", "label":"新建视频"},
{"reactionDefs":[],"group":"BLOG","type":"BLOG_CREATED", "label":"发布博客"},
{"reactionDefs":[],"group":"BLOG","type":"BLOG_COMMENT", "label":"评论"},
{"reactionDefs":[],"group":"BLOG","type":"BLOG_OTHER", "label":"博客更新"},
{"reactionDefs":[],"group":"","type":"APP_INSTALLED", "label":"新装应用"},
{"reactionDefs":[],"group":"","type":"FAVORITES", "label":"收藏更新"},
{"reactionDefs":[],"group":"","type":"LOCATION_UPDATE", "label":"位置更新"},
{"reactionDefs":[],"group":"MUSIC","type":"MUSIC_ADDED", "label":"新加音乐"},
{"reactionDefs":[],"group":"VIDEO","type":"VIDEO_ADDED", "label":"新加视频"},
{"reactionDefs":[],"group":"","type":"POKE", "label":"打招呼"},
{"reactionDefs":[],"group":"MUSIC","type":"LOVED_TRACKS", "label":"喜欢的乐曲"},
{"reactionDefs":[],"group":"MUSIC","type":"TOP_ARTIST", "label":"作曲家排行榜更新"},
{"reactionDefs":[],"group":"MUSIC","type":"TOP_ALBUM", "label":"专辑排行榜更新"},
{"reactionDefs":[],"group":"MUSIC","type":"TOP_TAG", "label":"标签排行榜"},
{"reactionDefs":[],"group":"MUSIC","type":"TOP_TRACK", "label":"热门歌曲排行榜"},
{"reactionDefs":[],"group":"","type":"OTHER", "label":"更新"}
]}
', '', '');
insert into services ("_id", "dirty", "sync_id", "providers_id", "capability", "server_address", "server_port", "secure", "path", "pretty_name", "auth_type", "settings", "email_pattern", "login_replacement") values ('326', '0', 'sNdl7IxzSBusjDNiuLD4bA==', '321', '8', '', '0', '0', 'SinaMicroblog Status.png', 'sinamicroblog_status', '0', '
    {"pushProviderID":12,"label":"状态更新","maxLength":140,"clearStatusSupported":0,"photoSupported":"0","supportsRetweet":1,"supportsComments":1, 
     "statusReactionDefs":[{"userParamDefs":[{"maxLength":140,"name":"comment","label":"添加评论","type":"string"}],"order":1,"name":"comment","label":"添加评论","type":"comment","icons":{"card":"ic_card_comment.png"},"messages":{"ok":"评论已发送","fail":"发送评论失败"}}],
     "statusReactionDefs3":[{
		"userParamDefs": [{
                "maxLength": 140,
                "name": "comment",
                "label": "Retweet with Comment",
                "type": "string",
                "postfix": "RT @{friendName} {status}",
                "totalMaxLength": 140
            }],"order":3,"name":"retweet","label":"转发","icons":{"card":"ic_card_retweet.png"},"messages":{"ok":"转发成功","fail":"无法转发微博","confirm":"转发至你的粉丝?"}}],
       "statusReactionDefs5": [{
           "userParamDefs": [{
                "maxLength": 140,
                "name": "comment",
                "label": "Retweet with Comment",
                "type": "string",
                "postfix": "RT @{friendName} {status}",
                "totalMaxLength": 140
            }],
            "order": 4,
            "name": "retweetWithComment",
            "label": "Retweet with Comment",
            "icons":{"card":"ic_card_retweet_comment.png"},
            "messages": {
                "ok": "评论已发送",
                "fail": "发送评论失败 新浪微博"
            }
       }]
    }         
', '', '');
